-- Keep the existing signup trigger behavior and also persist the submitted phone.
-- Run this migration in Supabase SQL Editor. It does not alter or disable RLS.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
BEGIN
    INSERT INTO public.profiles (id, full_name, phone)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data ->> 'full_name', ''),
        NULLIF(BTRIM(COALESCE(NEW.raw_user_meta_data ->> 'phone', '')), '')
    );

    INSERT INTO public.membership_requests (
        user_id,
        motivation,
        status
    )
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data ->> 'motivation', ''),
        'pending'
    );

    RETURN NEW;
END;
$function$;
