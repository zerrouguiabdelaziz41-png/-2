-- Refresh the admin-only membership request listing with safe fallbacks
-- to Auth metadata when profile fields were not populated by an older signup trigger.
CREATE OR REPLACE FUNCTION public.admin_list_membership_requests()
RETURNS TABLE (
    request_id uuid,
    user_id uuid,
    full_name text,
    email text,
    phone text,
    motivation text,
    status text,
    created_at timestamptz,
    admin_notes text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO ''
AS $function$
    SELECT
        r.id AS request_id,
        r.user_id,
        COALESCE(
            NULLIF(BTRIM(p.full_name), ''),
            NULLIF(BTRIM(u.raw_user_meta_data ->> 'full_name'), ''),
            NULLIF(BTRIM(u.raw_user_meta_data ->> 'name'), ''),
            'الاسم غير متوفر'
        ) AS full_name,
        COALESCE(u.email::text, '') AS email,
        COALESCE(
            NULLIF(BTRIM(p.phone), ''),
            NULLIF(BTRIM(u.raw_user_meta_data ->> 'phone'), ''),
            'غير متوفر'
        ) AS phone,
        COALESCE(
            NULLIF(BTRIM(r.motivation), ''),
            NULLIF(BTRIM(u.raw_user_meta_data ->> 'motivation'), ''),
            NULLIF(BTRIM(u.raw_user_meta_data ->> 'bio'), ''),
            ''
        ) AS motivation,
        r.status,
        r.created_at,
        r.admin_notes
    FROM public.membership_requests AS r
    JOIN auth.users AS u ON u.id = r.user_id
    LEFT JOIN public.profiles AS p ON p.id = r.user_id
    WHERE (SELECT private.is_admin())
    ORDER BY r.created_at DESC;
$function$;

REVOKE ALL ON FUNCTION public.admin_list_membership_requests() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.admin_list_membership_requests() FROM anon;
GRANT EXECUTE ON FUNCTION public.admin_list_membership_requests() TO authenticated;
